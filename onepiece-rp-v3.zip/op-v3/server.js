require('dotenv').config();
const express = require('express');
const path    = require('path');
const http    = require('http');
const { Server } = require('socket.io');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

// ── Codes d'accès (modifiables via .env) ─────────────────
const CODES = {
  master: process.env.CODE_MASTER || 'TartifletteDeLaHess',
  super:  process.env.CODE_SUPER  || 'Tartiflette',
  admin:  process.env.CODE_ADMIN  || 'RedaLeGoat'
};

// ── Données en mémoire ────────────────────────────────────
// Note : Railway/Render ont un filesystem éphémère.
// Les données sont gardées EN MÉMOIRE pendant la session.
// Pour la persistance, utiliser une DB externe (MongoDB Atlas gratuit).
let players    = {};
let worldEvent = "⛵ L'horizon est dégagé... les mers vous attendent.";
let msgHistory = []; // 100 derniers messages

const SKILL_COSTS = { force: 1, intel: 1, haki: 3, reading: 10 };
const FACTION_COLORS = { pirate: '#ff4757', marine: '#2e86de', revo: '#2ed573' };

const FACTION_GRADES = {
  pirate: ['Mousse','Matelot','Second','Capitaine','Commodore','Amiral de flotte'],
  marine: ['Recrue','Soldat','Sergent','Lieutenant','Capitaine','Vice-amiral','Amiral'],
  revo:   ['Partisan','Agent','Chef de cellule','Officier','Commandant','Général']
};

const WORLD_EVENTS_LIST = [
  '⚔️ Bataille de Marineford — Chaque action compte !',
  '🏝️ Île mystérieuse apparue sur les cartes — Explorez !',
  '🏛️ La Reverie — Intrigues au sommet des rois',
  '🌊 Tempête du Grand Line — Survivez ensemble !',
  '🐉 Créature des Abysses — Unissez-vous pour vaincre !',
  '⚓ Chasse aux Quatre Empereurs — Opération majeure !'
];

// Quêtes
let quests = [
  { id:1, title:'Première Traversée',   desc:'Rédigez votre premier post RP.',       faction:'all',    reward:500,   xp:50,  done:[] },
  { id:2, title:'Chasse à la Prime',    desc:'Participez à un combat en RP.',         faction:'pirate', reward:2000,  xp:100, done:[] },
  { id:3, title:'Justice et Ordre',     desc:'Rédigez un post d\'arrestation.',       faction:'marine', reward:0,     xp:150, done:[] },
  { id:4, title:'Flamme de la Liberté', desc:'Recrutez un allié narratif.',           faction:'revo',   reward:0,     xp:120, done:[] },
  { id:5, title:'Terres Inconnues',     desc:'Ouvrez un nouvel arc narratif.',        faction:'all',    reward:1000,  xp:80,  done:[] },
  { id:6, title:'Duel Légendaire',      desc:'Organisez un duel RP en 2 posts.',      faction:'all',    reward:1500,  xp:200, done:[] }
];

// ── Static ────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Socket.io ─────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log('[+]', socket.id);

  // Envoie l'état complet au nouveau connecté
  socket.emit('init', {
    worldEvent,
    players,
    history: msgHistory,
    quests
  });

  // ── JOIN ──────────────────────────────────────────────
  socket.on('join', ({ name, faction }) => {
    socket.playerName = name;
    socket.faction    = faction;

    if (!players[name]) {
      players[name] = {
        name,
        faction: faction || 'pirate',
        bounty:      1000,
        gradeXP:     0,
        gradeIdx:    0,
        grade:       FACTION_GRADES[faction]?.[0] || 'Mousse',
        skillPoints: 0,
        skills:      { force: 0, intel: 0, haki: 0, reading: 0 }
      };
    }

    io.emit('leaderboard-update', players);
    socket.emit('player-data', players[name]);
    io.emit('system-msg', `🌊 ${name} a rejoint les mers !`);
  });

  // ── MESSAGE RP ────────────────────────────────────────
  socket.on('rp-message', ({ user, text, faction }) => {
    const p = players[user];
    if (!p || !text?.trim()) return;

    // Prime dynamique
    p.bounty  += Math.floor(Math.random() * 250) + 150;
    p.gradeXP += 10;

    // Skill point tous les 500 XP
    if (p.gradeXP > 0 && p.gradeXP % 500 < 10) p.skillPoints++;

    // Montée de grade auto
    checkGrade(user);

    const msg = {
      user,
      text: text.trim(),
      faction: p.faction,
      ts: Date.now()
    };
    msgHistory.push(msg);
    if (msgHistory.length > 100) msgHistory.shift();

    io.emit('rp-message', msg);
    io.emit('leaderboard-update', players);
    socket.emit('player-data', p);
  });

  // ── SKILLS ───────────────────────────────────────────
  socket.on('upgrade-skill', (skill) => {
    const p = players[socket.playerName];
    if (!p || !SKILL_COSTS[skill]) return;
    if (p.skillPoints < SKILL_COSTS[skill]) return;
    p.skillPoints -= SKILL_COSTS[skill];
    p.skills[skill]++;
    socket.emit('player-data', p);
    io.emit('leaderboard-update', players);
  });

  // ── QUÊTES ───────────────────────────────────────────
  socket.on('quest-complete', ({ user, questId }) => {
    const q = quests.find(x => x.id === questId);
    const p = players[user];
    if (!q || !p || q.done.includes(user)) return;
    q.done.push(user);
    p.bounty  += q.reward;
    p.gradeXP += q.xp;
    if (p.gradeXP % 500 < q.xp) p.skillPoints++;
    checkGrade(user);
    socket.emit('player-data', p);
    io.emit('quest-update', quests);
    io.emit('system-msg', `✅ ${user} a accompli la quête "${q.title}" !`);
    io.emit('leaderboard-update', players);
  });

  // ── ADMIN AUTH ───────────────────────────────────────
  socket.on('admin-auth', (code, cb) => {
    if      (code === CODES.master) cb({ level: 'master',    label: 'MAÎTRE — ACCÈS TOTAL' });
    else if (code === CODES.super)  cb({ level: 'supermodo', label: 'SUPER MODO' });
    else if (code === CODES.admin)  cb({ level: 'admin',     label: 'ADMINISTRATEUR' });
    else                            cb(false);
  });

  // ── ADMIN ACTIONS ────────────────────────────────────
  socket.on('admin-action', ({ type, value, code, target }) => {
    const lvl = getLevel(code);
    if (!lvl) return;

    // Événement mondial (super+)
    if (type === 'event' && (lvl === 'master' || lvl === 'supermodo')) {
      worldEvent = value;
      io.emit('world-event-update', value);
    }

    // Trigger événement prédéfini (super+)
    if (type === 'trigger-event' && (lvl === 'master' || lvl === 'supermodo')) {
      worldEvent = WORLD_EVENTS_LIST[value] || worldEvent;
      io.emit('world-event-update', worldEvent);
      io.emit('system-msg', `⚡ ÉVÉNEMENT MONDIAL : ${worldEvent}`);
    }

    // Modifier prime (tous niveaux)
    if (type === 'set-bounty') {
      const p = players[target];
      if (p) {
        p.bounty = Number(value);
        io.emit('leaderboard-update', players);
        io.emit('system-msg', `⚠️ AVIS DE RECHERCHE : Prime de ${target} fixée à ${Number(value).toLocaleString()} ฿`);
        const tSocket = [...io.sockets.sockets.values()].find(s => s.playerName === target);
        tSocket?.emit('player-data', p);
      }
    }

    // Modifier grade (tous niveaux)
    if (type === 'set-grade') {
      const p = players[target];
      if (p) {
        p.grade = value;
        io.emit('leaderboard-update', players);
        io.emit('system-msg', `📋 ${target} a été promu(e) : ${value}`);
        const tSocket = [...io.sockets.sockets.values()].find(s => s.playerName === target);
        tSocket?.emit('player-data', p);
      }
    }

    // Reset stats (admin+)
    if (type === 'reset' && (lvl === 'master' || lvl === 'supermodo' || lvl === 'admin')) {
      const p = players[target];
      if (p) {
        p.bounty = 1000; p.gradeXP = 0; p.gradeIdx = 0;
        p.skillPoints = 0; p.skills = { force:0, intel:0, haki:0, reading:0 };
        p.grade = FACTION_GRADES[p.faction]?.[0] || 'Mousse';
        io.emit('leaderboard-update', players);
        io.emit('system-msg', `🔄 Stats de ${target} réinitialisées.`);
        const tSocket = [...io.sockets.sockets.values()].find(s => s.playerName === target);
        tSocket?.emit('player-data', p);
      }
    }

    // Expulser (admin+)
    if (type === 'kick') {
      const tSocket = [...io.sockets.sockets.values()].find(s => s.playerName === target);
      if (tSocket) { tSocket.emit('kicked'); tSocket.disconnect(); }
      delete players[target];
      io.emit('leaderboard-update', players);
      io.emit('system-msg', `🚫 ${target} a été expulsé(e).`);
    }

    // Changer de faction (admin+)
    if (type === 'set-faction') {
      const p = players[target];
      if (p && ['pirate','marine','revo'].includes(value)) {
        p.faction = value;
        p.grade   = FACTION_GRADES[value]?.[0] || 'Mousse';
        p.gradeIdx = 0;
        io.emit('leaderboard-update', players);
        io.emit('system-msg', `⚓ ${target} a rejoint les ${value}s.`);
      }
    }

    // Annoncement global (tous niveaux)
    if (type === 'announce') {
      io.emit('show-announcement', value);
      io.emit('system-msg', `📢 JOURNAL MUNDI : ${value}`);
    }

    // Créer une nouvelle quête (master)
    if (type === 'add-quest' && lvl === 'master') {
      quests.push({ id: Date.now(), title: value.title, desc: value.desc, faction: value.faction || 'all', reward: value.reward || 0, xp: value.xp || 50, done: [] });
      io.emit('quest-update', quests);
    }
  });

  // ── WANTED POSTER ────────────────────────────────────
  socket.on('send-poster', ({ targetName, imageUrl, code }) => {
    const lvl = getLevel(code);
    if (!lvl || lvl === 'admin') return; // admin ne peut pas envoyer de poster
    const p = players[targetName];
    if (!p) return;
    io.emit('show-poster', {
      targetName,
      imageUrl,
      bounty:  p.bounty,
      faction: p.faction,
      grade:   p.grade
    });
  });

  // ── DISCONNECT ───────────────────────────────────────
  socket.on('disconnect', () => {
    if (socket.playerName) {
      io.emit('system-msg', `👋 ${socket.playerName} a quitté les mers.`);
      io.emit('leaderboard-update', players);
    }
  });
});

// ── Helpers ───────────────────────────────────────────────
function getLevel(code) {
  if (code === CODES.master) return 'master';
  if (code === CODES.super)  return 'supermodo';
  if (code === CODES.admin)  return 'admin';
  return null;
}

function checkGrade(name) {
  const p = players[name];
  if (!p) return;
  const grades     = FACTION_GRADES[p.faction] || [];
  const thresholds = [0, 100, 300, 700, 1500, 3000, 6000];
  const nextXP     = thresholds[(p.gradeIdx || 0) + 1];
  if (nextXP && p.gradeXP >= nextXP && (p.gradeIdx || 0) + 1 < grades.length) {
    p.gradeIdx++;
    p.grade = grades[p.gradeIdx];
    io.emit('system-msg', `🎉 ${name} vient d'être promu(e) : ${p.grade} !`);
    io.emit('leaderboard-update', players);
  }
}

// ── Boot ──────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`⚓ Grand Line Horizon V3 — port ${PORT}`));
